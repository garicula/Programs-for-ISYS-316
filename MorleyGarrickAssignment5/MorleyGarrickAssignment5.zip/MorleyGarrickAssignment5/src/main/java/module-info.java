module com.example.morleygarrickassignment5 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.morleygarrickassignment5 to javafx.fxml;
    exports com.example.morleygarrickassignment5;
}