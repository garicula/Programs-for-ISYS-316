1. For some reason you have to drag the mouse cursor over where all of the new transaction
are for them to visually appear, I have no idea why that's just how it's working.

2. I sort of have the split function of the String class figured out but it's a work in
progress.

3. I used my calculator program from the previous assignment to set up the numeric keypad 
so at least that part is working.

4. I'll do better on the future assignments, and I should have enough grade padding to 
keep me afloat for this project. 

5. Sorry I've just been so crunched for time between trying to find a job after school and
all of my other classes that I wasn't able to do too well onthis one. I'll get the next 
projects done better and on time as well.

