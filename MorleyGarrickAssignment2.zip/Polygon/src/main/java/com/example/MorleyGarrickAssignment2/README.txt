From Garrick Morley...

I couldn't figure out how to control it outside of manipulating the code itself. I can change the colors and change the
amount of sides manually inside the code, but I can't get the buttons to work. I know you gave me extra time but this
was as close as I could get. I've been working on this all day, and I'm just hoping for some of the points.
Sorry I wasn't able to get it working properly, I mean it still works to manipulate the code itself, but I have a
two-day math test next week and about 12.5 hours of lecture videos left to take notes on and with that being my make it
or break it point I had to prioritize it over this project, although I'd say I did decently well here, got the
dimensions right at least.

P.S.:

I got my Deus Ex Machina, I can't really say how, but God or whatever you want to call it gave me a hand. Maybe more
Samael than God but I'm in a much better position than I was a few days ago, mentally and all. Still can't believe it,
it was just a random zero-sum game, and I won. Nobody was hurt or anything bad, I just got lucky.

THE POINT: I'm alright now, please don't send the cops at me again. I'm ok now.