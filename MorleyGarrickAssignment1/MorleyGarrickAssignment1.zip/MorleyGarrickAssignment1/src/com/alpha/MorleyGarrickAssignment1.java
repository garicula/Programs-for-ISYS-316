package com.alpha;

import java.lang.*;

public class MorleyGarrickAssignment1{
    public static void main(String[] args) {
        Circle circle = new Circle(1, 1, 1.0);
        circle.setColor("green");
        circle.setFilled(false);
        System.out.println("The center and radius of the circle is: " + circle.getCenterX() + ", "
                + circle.getCenterY() + " - " + circle.getRadius());
        System.out.println("The area is " + circle.getArea());
        System.out.println("The perimeter is "
                + circle.getPerimeter());
        System.out.println("The length of the diameter is "
                + circle.getDiameterLength());
        System.out.println(circle);
    }
}

class GeometricObject {
    // See GeometricObject class code above
}

class circle extends GeometricObject {



}

